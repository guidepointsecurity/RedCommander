'''

##########################################
Data set containing common dns subdomains. 
##########################################

'''
#Customize this#
subdomains = ['ns0','ns1','ns2']