'''

##################################################################################
Data set containing common transformations for payload transformation.
##################################################################################

'''

transformations = ['base64','base64url','mask','netbios','netbiosu']